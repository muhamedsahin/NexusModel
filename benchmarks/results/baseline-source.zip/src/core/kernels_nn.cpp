#include "nexus_model/core/error.hpp"
#include "nexus_model/core/kernels.hpp"

#include <algorithm>
#include <cmath>
#include <cstdint>

namespace nexus_model::kernels {
namespace {

int product3(const int s[3]) { return s[0] * s[1] * s[2]; }

void align3(const ConvDesc& d, int in_s[3], int out_s[3], int ker[3], int str[3], int pad[3], int dil[3]) {
  for (int i = 0; i < 3; ++i) {
    in_s[i] = 1;
    out_s[i] = 1;
    ker[i] = 1;
    str[i] = 1;
    pad[i] = 0;
    dil[i] = 1;
  }
  for (int i = 0; i < d.rank; ++i) {
    const int slot = 3 - d.rank + i;
    in_s[slot] = d.spatial_in[i];
    out_s[slot] = d.spatial_out[i];
    ker[slot] = d.kernel[i];
    str[slot] = d.stride[i];
    pad[slot] = d.pad[i];
    dil[slot] = d.dilation[i];
  }
}

void im2col_group(const float* x, float* col, int n, int g, int channels, int cin_g, const int in_s[3],
                  const int out_s[3], const int ker[3], const int str[3], const int pad[3], const int dil[3],
                  int in_spatial, int col_stride) {
  int s = 0;
  for (int od = 0; od < out_s[0]; ++od) {
    for (int oh = 0; oh < out_s[1]; ++oh) {
      for (int ow = 0; ow < out_s[2]; ++ow, ++s) {
        int col_c = 0;
        for (int ic = 0; ic < cin_g; ++ic) {
          for (int kd = 0; kd < ker[0]; ++kd) {
            for (int kh = 0; kh < ker[1]; ++kh) {
              for (int kw = 0; kw < ker[2]; ++kw, ++col_c) {
                const int id = od * str[0] - pad[0] + kd * dil[0];
                const int ih = oh * str[1] - pad[1] + kh * dil[1];
                const int iw = ow * str[2] - pad[2] + kw * dil[2];
                float value = 0.f;
                if (id >= 0 && id < in_s[0] && ih >= 0 && ih < in_s[1] && iw >= 0 && iw < in_s[2]) {
                  const int spat = (id * in_s[1] + ih) * in_s[2] + iw;
                  const int channel = g * cin_g + ic;
                  value = x[(static_cast<std::size_t>(n * channels + channel) * in_spatial) + spat];
                }
                col[static_cast<std::size_t>(s) * col_stride + col_c] = value;
              }
            }
          }
        }
      }
    }
  }
}

void col2im_group(const float* dcol, float* dx, int n, int g, int channels, int cin_g, const int in_s[3],
                  const int out_s[3], const int ker[3], const int str[3], const int pad[3], const int dil[3],
                  int in_spatial, int col_stride) {
  int s = 0;
  for (int od = 0; od < out_s[0]; ++od) {
    for (int oh = 0; oh < out_s[1]; ++oh) {
      for (int ow = 0; ow < out_s[2]; ++ow, ++s) {
        int col_c = 0;
        for (int ic = 0; ic < cin_g; ++ic) {
          for (int kd = 0; kd < ker[0]; ++kd) {
            for (int kh = 0; kh < ker[1]; ++kh) {
              for (int kw = 0; kw < ker[2]; ++kw, ++col_c) {
                const int id = od * str[0] - pad[0] + kd * dil[0];
                const int ih = oh * str[1] - pad[1] + kh * dil[1];
                const int iw = ow * str[2] - pad[2] + kw * dil[2];
                if (id < 0 || id >= in_s[0] || ih < 0 || ih >= in_s[1] || iw < 0 || iw >= in_s[2]) continue;
                const int spat = (id * in_s[1] + ih) * in_s[2] + iw;
                const int channel = g * cin_g + ic;
                dx[(static_cast<std::size_t>(n * channels + channel) * in_spatial) + spat] +=
                    dcol[static_cast<std::size_t>(s) * col_stride + col_c];
              }
            }
          }
        }
      }
    }
  }
}

}  // namespace

int conv_out_size(int input, int pad, int dilation, int kernel, int stride) {
  if (stride <= 0 || kernel <= 0 || dilation <= 0) throw ModelError("conv geometry must be positive");
  const int numer = input + 2 * pad - dilation * (kernel - 1) - 1;
  if (numer < 0) return 0;
  return numer / stride + 1;
}

std::size_t conv_col_size(const ConvDesc& d) {
  if (d.groups <= 0 || d.c % d.groups != 0 || d.k % d.groups != 0) {
    throw ModelError("conv groups must divide channels");
  }
  int out_p = 1;
  int kvol = 1;
  for (int i = 0; i < d.rank; ++i) {
    out_p *= d.spatial_out[i];
    kvol *= d.kernel[i];
  }
  return static_cast<std::size_t>(out_p) * static_cast<std::size_t>(d.c / d.groups) * static_cast<std::size_t>(kvol);
}

void conv_forward(const float* x, const float* w, const float* bias, float* y, float* col, const ConvDesc& d) {
  int in_s[3], out_s[3], ker[3], str[3], pad[3], dil[3];
  align3(d, in_s, out_s, ker, str, pad, dil);
  const int cin_g = d.c / d.groups;
  const int cout_g = d.k / d.groups;
  const int in_spatial = product3(in_s);
  const int out_spatial = product3(out_s);
  const int col_stride = cin_g * product3(ker);
  for (int n = 0; n < d.n; ++n) {
    for (int g = 0; g < d.groups; ++g) {
      im2col_group(x, col, n, g, d.c, cin_g, in_s, out_s, ker, str, pad, dil, in_spatial, col_stride);
      for (int oc = 0; oc < cout_g; ++oc) {
        const int oc_abs = g * cout_g + oc;
        const float* wrow = w + static_cast<std::size_t>(oc_abs) * col_stride;
        const float b = bias != nullptr ? bias[oc_abs] : 0.f;
        for (int s = 0; s < out_spatial; ++s) {
          y[(static_cast<std::size_t>(n * d.k + oc_abs) * out_spatial) + s] =
              dot(col + static_cast<std::size_t>(s) * col_stride, wrow, col_stride) + b;
        }
      }
    }
  }
}

void conv_backward(const float* x, const float* w, const float* dy, float* dx, float* dw, float* db, float* col,
                   const ConvDesc& d) {
  int in_s[3], out_s[3], ker[3], str[3], pad[3], dil[3];
  align3(d, in_s, out_s, ker, str, pad, dil);
  const int cin_g = d.c / d.groups;
  const int cout_g = d.k / d.groups;
  const int in_spatial = product3(in_s);
  const int out_spatial = product3(out_s);
  const int col_stride = cin_g * product3(ker);
  const std::size_t col_elems = static_cast<std::size_t>(out_spatial) * static_cast<std::size_t>(col_stride);
  float* dcol = col + col_elems;
  for (int n = 0; n < d.n; ++n) {
    for (int g = 0; g < d.groups; ++g) {
      im2col_group(x, col, n, g, d.c, cin_g, in_s, out_s, ker, str, pad, dil, in_spatial, col_stride);
      std::fill(dcol, dcol + col_elems, 0.f);
      for (int oc = 0; oc < cout_g; ++oc) {
        const int oc_abs = g * cout_g + oc;
        const float* wrow = w + static_cast<std::size_t>(oc_abs) * col_stride;
        float* dwrow = dw != nullptr ? dw + static_cast<std::size_t>(oc_abs) * col_stride : nullptr;
        for (int s = 0; s < out_spatial; ++s) {
          const float gval = dy[(static_cast<std::size_t>(n * d.k + oc_abs) * out_spatial) + s];
          axpy(dcol + static_cast<std::size_t>(s) * col_stride, wrow, gval, col_stride);
          if (dwrow != nullptr) axpy(dwrow, col + static_cast<std::size_t>(s) * col_stride, gval, col_stride);
          if (db != nullptr) db[oc_abs] += gval;
        }
      }
      if (dx != nullptr) {
        col2im_group(dcol, dx, n, g, d.c, cin_g, in_s, out_s, ker, str, pad, dil, in_spatial, col_stride);
      }
    }
  }
}

void batch_norm(const float* x, const float* gamma, const float* beta, float* y, float* save_mean, float* save_rstd,
                float* running_mean, float* running_var, int outer, int channels, int inner, float eps, float momentum,
                bool training, bool track_running) {
  const int m = outer * inner;
  if (m <= 0) throw ModelError("batch norm received an empty reduction");
  for (int c = 0; c < channels; ++c) {
    float mean = 0.f;
    float rstd = 0.f;
    if (training) {
      double sum = 0.0;
      for (int n = 0; n < outer; ++n) {
        for (int i = 0; i < inner; ++i) sum += x[(static_cast<std::size_t>(n * channels + c) * inner) + i];
      }
      mean = static_cast<float>(sum / m);
      double var_acc = 0.0;
      for (int n = 0; n < outer; ++n) {
        for (int i = 0; i < inner; ++i) {
          const double diff = x[(static_cast<std::size_t>(n * channels + c) * inner) + i] - mean;
          var_acc += diff * diff;
        }
      }
      const float var = static_cast<float>(var_acc / m);
      rstd = 1.f / std::sqrt(var + eps);
      if (track_running && running_mean != nullptr && running_var != nullptr) {
        running_mean[c] = (1.f - momentum) * running_mean[c] + momentum * mean;
        const float unbiased = m > 1 ? static_cast<float>(var_acc / (m - 1)) : var;
        running_var[c] = (1.f - momentum) * running_var[c] + momentum * unbiased;
      }
    } else {
      mean = running_mean != nullptr ? running_mean[c] : 0.f;
      const float var = running_var != nullptr ? running_var[c] : 1.f;
      rstd = 1.f / std::sqrt(var + eps);
    }
    save_mean[c] = mean;
    save_rstd[c] = rstd;
    const float g = gamma != nullptr ? gamma[c] : 1.f;
    const float b = beta != nullptr ? beta[c] : 0.f;
    for (int n = 0; n < outer; ++n) {
      for (int i = 0; i < inner; ++i) {
        const std::size_t idx = (static_cast<std::size_t>(n * channels + c) * inner) + i;
        y[idx] = (x[idx] - mean) * rstd * g + b;
      }
    }
  }
}

void batch_norm_bwd(const float* x, const float* gamma, const float* save_mean, const float* save_rstd, const float* dy,
                    float* dx, float* dgamma, float* dbeta, int outer, int channels, int inner) {
  const int m = outer * inner;
  const float inv_m = 1.f / static_cast<float>(m);
  for (int c = 0; c < channels; ++c) {
    const float mean = save_mean[c];
    const float rstd = save_rstd[c];
    const float g = gamma != nullptr ? gamma[c] : 1.f;
    double sum_dy = 0.0;
    double sum_dy_xhat = 0.0;
    for (int n = 0; n < outer; ++n) {
      for (int i = 0; i < inner; ++i) {
        const std::size_t idx = (static_cast<std::size_t>(n * channels + c) * inner) + i;
        const float xhat = (x[idx] - mean) * rstd;
        const float dys = dy[idx] * g;
        sum_dy += dys;
        sum_dy_xhat += static_cast<double>(dys) * xhat;
        if (dgamma != nullptr) dgamma[c] += dy[idx] * xhat;
        if (dbeta != nullptr) dbeta[c] += dy[idx];
      }
    }
    for (int n = 0; n < outer; ++n) {
      for (int i = 0; i < inner; ++i) {
        const std::size_t idx = (static_cast<std::size_t>(n * channels + c) * inner) + i;
        const float xhat = (x[idx] - mean) * rstd;
        const float dys = dy[idx] * g;
        dx[idx] = rstd * inv_m *
                  (static_cast<float>(m) * dys - static_cast<float>(sum_dy) - xhat * static_cast<float>(sum_dy_xhat));
      }
    }
  }
}

void group_norm(const float* x, const float* gamma, const float* beta, float* y, float* save_mean, float* save_rstd,
                int n, int channels, int inner, int groups, float eps) {
  if (groups <= 0 || channels % groups != 0) throw ModelError("group norm groups must divide channels");
  const int cpg = channels / groups;
  const int m = cpg * inner;
  for (int ni = 0; ni < n; ++ni) {
    for (int g = 0; g < groups; ++g) {
      double sum = 0.0;
      for (int c = 0; c < cpg; ++c) {
        const int ch = g * cpg + c;
        for (int i = 0; i < inner; ++i) sum += x[(static_cast<std::size_t>(ni * channels + ch) * inner) + i];
      }
      const float mean = static_cast<float>(sum / m);
      double var_acc = 0.0;
      for (int c = 0; c < cpg; ++c) {
        const int ch = g * cpg + c;
        for (int i = 0; i < inner; ++i) {
          const double diff = x[(static_cast<std::size_t>(ni * channels + ch) * inner) + i] - mean;
          var_acc += diff * diff;
        }
      }
      const float rstd = 1.f / std::sqrt(static_cast<float>(var_acc / m) + eps);
      save_mean[ni * groups + g] = mean;
      save_rstd[ni * groups + g] = rstd;
      for (int c = 0; c < cpg; ++c) {
        const int ch = g * cpg + c;
        const float gv = gamma != nullptr ? gamma[ch] : 1.f;
        const float bv = beta != nullptr ? beta[ch] : 0.f;
        for (int i = 0; i < inner; ++i) {
          const std::size_t idx = (static_cast<std::size_t>(ni * channels + ch) * inner) + i;
          y[idx] = (x[idx] - mean) * rstd * gv + bv;
        }
      }
    }
  }
}

void group_norm_bwd(const float* x, const float* gamma, const float* save_mean, const float* save_rstd, const float* dy,
                    float* dx, float* dgamma, float* dbeta, int n, int channels, int inner, int groups) {
  const int cpg = channels / groups;
  const int m = cpg * inner;
  const float inv_m = 1.f / static_cast<float>(m);
  for (int ni = 0; ni < n; ++ni) {
    for (int g = 0; g < groups; ++g) {
      const float mean = save_mean[ni * groups + g];
      const float rstd = save_rstd[ni * groups + g];
      double sum_dy = 0.0;
      double sum_dy_xhat = 0.0;
      for (int c = 0; c < cpg; ++c) {
        const int ch = g * cpg + c;
        const float gv = gamma != nullptr ? gamma[ch] : 1.f;
        for (int i = 0; i < inner; ++i) {
          const std::size_t idx = (static_cast<std::size_t>(ni * channels + ch) * inner) + i;
          const float xhat = (x[idx] - mean) * rstd;
          const float dys = dy[idx] * gv;
          sum_dy += dys;
          sum_dy_xhat += static_cast<double>(dys) * xhat;
          if (dgamma != nullptr) dgamma[ch] += dy[idx] * xhat;
          if (dbeta != nullptr) dbeta[ch] += dy[idx];
        }
      }
      for (int c = 0; c < cpg; ++c) {
        const int ch = g * cpg + c;
        const float gv = gamma != nullptr ? gamma[ch] : 1.f;
        for (int i = 0; i < inner; ++i) {
          const std::size_t idx = (static_cast<std::size_t>(ni * channels + ch) * inner) + i;
          const float xhat = (x[idx] - mean) * rstd;
          const float dys = dy[idx] * gv;
          dx[idx] = rstd * inv_m * (static_cast<float>(m) * dys - static_cast<float>(sum_dy) -
                                    xhat * static_cast<float>(sum_dy_xhat));
        }
      }
    }
  }
}

void max_pool2d(const float* x, float* y, int* index, int n, int c, int h, int w, int kh, int kw, int sh, int sw, int ph,
                int pw) {
  const int oh = conv_out_size(h, ph, 1, kh, sh);
  const int ow = conv_out_size(w, pw, 1, kw, sw);
  for (int ni = 0; ni < n; ++ni) {
    for (int ci = 0; ci < c; ++ci) {
      const float* src = x + (static_cast<std::size_t>(ni * c + ci) * h) * w;
      for (int oy = 0; oy < oh; ++oy) {
        for (int ox = 0; ox < ow; ++ox) {
          float best = -1e30f;
          int best_i = -1;
          for (int ky = 0; ky < kh; ++ky) {
            for (int kx = 0; kx < kw; ++kx) {
              const int iy = oy * sh - ph + ky;
              const int ix = ox * sw - pw + kx;
              if (iy < 0 || iy >= h || ix < 0 || ix >= w) continue;
              const int flat = iy * w + ix;
              if (src[flat] > best) {
                best = src[flat];
                best_i = flat;
              }
            }
          }
          const std::size_t oidx = (((static_cast<std::size_t>(ni) * c + ci) * oh) + oy) * ow + ox;
          y[oidx] = best_i >= 0 ? best : 0.f;
          index[oidx] = best_i;
        }
      }
    }
  }
}

void max_pool2d_bwd(const float* dy, const int* index, float* dx, int n, int c, int oh, int ow, int in_spatial) {
  const std::size_t out_n = static_cast<std::size_t>(n) * c * oh * ow;
  for (std::size_t i = 0; i < out_n; ++i) {
    if (index[i] < 0) continue;
    const int ni = static_cast<int>(i / (static_cast<std::size_t>(c) * oh * ow));
    const int rem = static_cast<int>(i % (static_cast<std::size_t>(c) * oh * ow));
    const int ci = rem / (oh * ow);
    dx[(static_cast<std::size_t>(ni * c + ci) * in_spatial) + index[i]] += dy[i];
  }
}

void avg_pool2d(const float* x, float* y, int n, int c, int h, int w, int kh, int kw, int sh, int sw, int ph, int pw,
                bool count_include_pad) {
  const int oh = conv_out_size(h, ph, 1, kh, sh);
  const int ow = conv_out_size(w, pw, 1, kw, sw);
  for (int ni = 0; ni < n; ++ni) {
    for (int ci = 0; ci < c; ++ci) {
      const float* src = x + (static_cast<std::size_t>(ni * c + ci) * h) * w;
      for (int oy = 0; oy < oh; ++oy) {
        for (int ox = 0; ox < ow; ++ox) {
          float sum = 0.f;
          int valid = 0;
          for (int ky = 0; ky < kh; ++ky) {
            for (int kx = 0; kx < kw; ++kx) {
              const int iy = oy * sh - ph + ky;
              const int ix = ox * sw - pw + kx;
              if (iy < 0 || iy >= h || ix < 0 || ix >= w) continue;
              sum += src[iy * w + ix];
              ++valid;
            }
          }
          const int denom = count_include_pad ? kh * kw : std::max(valid, 1);
          const std::size_t oidx = (((static_cast<std::size_t>(ni) * c + ci) * oh) + oy) * ow + ox;
          y[oidx] = valid == 0 ? 0.f : sum / static_cast<float>(denom);
        }
      }
    }
  }
}

void avg_pool2d_bwd(const float* dy, float* dx, int n, int c, int h, int w, int kh, int kw, int sh, int sw, int ph,
                    int pw, bool count_include_pad) {
  const int oh = conv_out_size(h, ph, 1, kh, sh);
  const int ow = conv_out_size(w, pw, 1, kw, sw);
  for (int ni = 0; ni < n; ++ni) {
    for (int ci = 0; ci < c; ++ci) {
      float* dst = dx + (static_cast<std::size_t>(ni * c + ci) * h) * w;
      for (int oy = 0; oy < oh; ++oy) {
        for (int ox = 0; ox < ow; ++ox) {
          int valid = 0;
          for (int ky = 0; ky < kh; ++ky) {
            for (int kx = 0; kx < kw; ++kx) {
              const int iy = oy * sh - ph + ky;
              const int ix = ox * sw - pw + kx;
              if (iy >= 0 && iy < h && ix >= 0 && ix < w) ++valid;
            }
          }
          const int denom = count_include_pad ? kh * kw : std::max(valid, 1);
          const float share = dy[(((static_cast<std::size_t>(ni) * c + ci) * oh) + oy) * ow + ox] / static_cast<float>(denom);
          if (valid == 0) continue;
          for (int ky = 0; ky < kh; ++ky) {
            for (int kx = 0; kx < kw; ++kx) {
              const int iy = oy * sh - ph + ky;
              const int ix = ox * sw - pw + kx;
              if (iy < 0 || iy >= h || ix < 0 || ix >= w) continue;
              dst[iy * w + ix] += share;
            }
          }
        }
      }
    }
  }
}

void embedding_forward(const float* table, const float* indices, float* y, int rows, int dim, int vocab,
                       int padding_idx) {
  for (int r = 0; r < rows; ++r) {
    const int idx = static_cast<int>(indices[r]);
    float* dst = y + static_cast<std::size_t>(r) * dim;
    if (idx == padding_idx) {
      std::fill(dst, dst + dim, 0.f);
      continue;
    }
    if (idx < 0 || idx >= vocab) throw ModelError("embedding index out of range");
    const float* src = table + static_cast<std::size_t>(idx) * dim;
    std::copy(src, src + dim, dst);
  }
}

void embedding_backward(const float* grad, const float* indices, float* dtable, int rows, int dim, int vocab,
                        int padding_idx) {
  for (int r = 0; r < rows; ++r) {
    const int idx = static_cast<int>(indices[r]);
    if (idx == padding_idx) continue;
    if (idx < 0 || idx >= vocab) throw ModelError("embedding index out of range");
    axpy(dtable + static_cast<std::size_t>(idx) * dim, grad + static_cast<std::size_t>(r) * dim, 1.f, dim);
  }
}

void dropout_mask(float* mask, std::size_t n, float p, std::uint64_t seed) {
  if (p <= 0.f) {
    std::fill(mask, mask + n, 1.f);
    return;
  }
  if (p >= 1.f) {
    std::fill(mask, mask + n, 0.f);
    return;
  }
  std::uint64_t state = seed ? seed : 0x9E3779B97F4A7C15ull;
  for (std::size_t i = 0; i < n; ++i) {
    state ^= state << 13;
    state ^= state >> 7;
    state ^= state << 17;
    const float u = static_cast<float>(state >> 40) * (1.f / 16777216.f);
    mask[i] = u >= p ? 1.f : 0.f;
  }
}

}  // namespace nexus_model::kernels
